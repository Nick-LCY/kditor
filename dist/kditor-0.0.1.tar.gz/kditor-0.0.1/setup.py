import setuptools
setuptools.setup(
    name="kditor",
    version="0.0.1",
    author="NickLin",
    description="A module that helps you to modify yaml file easily.",
    packages=["kditor"]
)